﻿/*--------------------------------------------------
 / Developed for 2014
 --------------------------------------------------- */

// CSRF Token for ajax
var data = {}, csrfParam = $('meta[name="csrf-param"]').attr("content");
data[csrfParam] = $('meta[name="csrf-token"]').attr("content");
$.ajaxSetup({data: data});

window.ParsleyConfig = {
    uiEnabled: true,
    errorsWrapper: "",
    errorTemplate: "",
    errorClass: "error",
    successClass: "correct"
};

$(document).ready(function () {/* on load */

    /* new 2015.05.21 */
    //	 на все ссылки якорь которых начинается на #
    $('a[href^="#screen"]').bind('click.smoothscroll', function (e) {
        e.preventDefault();

        var target = this.hash,
            $target = $(target);

        $('html, body').stop().animate({
            'scrollTop': $target.offset().top
        }, 900, 'swing', function () {
            window.location.hash = target;
        });
    });

    $("#r_website").focus(function () {
        var el = $(this);
        console.log("Focus: " + el.val());
        if (el.val() == "") {
            el.val("http://")
        }
    }).blur(function () {
        var el = $(this);
        console.log("Blur: " + el.val());
        if (el.val() == "http://") {
            el.val("")
        }
    });

    $("#r_country").autocomplete({ source: ["Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Antarctic Territory", "British Indian Ocean Territory", "British Virgin Islands", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cambodia", "Cameroon", "Canada", "Canton and Enderbury Islands", "Cape Verde", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos [Keeling] Islands", "Colombia", "Comoros", "Congo - Brazzaville", "Congo - Kinshasa", "Cook Islands", "Costa Rica", "Croatia", "Cuba", "Cyprus", "Czech Republic", "Côte d’Ivoire", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Dronning Maud Land", "East Germany", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Ethiopia", "Falkland Islands", "Faroe Islands", "Fiji", "Finland", "France", "French Guiana", "French Polynesia", "French Southern Territories", "French Southern and Antarctic Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard Island and McDonald Islands", "Honduras", "Hong Kong SAR China", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Johnston Island", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macau SAR China", "Macedonia", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Metropolitan France", "Mexico", "Micronesia", "Midway Islands", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Myanmar [Burma]", "Namibia", "Nauru", "Nepal", "Netherlands", "Netherlands Antilles", "Neutral Zone", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "North Korea", "North Vietnam", "Northern Mariana Islands", "Norway", "Oman", "Pacific Islands Trust Territory", "Pakistan", "Palau", "Palestinian Territories", "Panama", "Panama Canal Zone", "Papua New Guinea", "Paraguay", "People's Democratic Republic of Yemen", "Peru", "Philippines", "Pitcairn Islands", "Poland", "Portugal", "Puerto Rico", "Qatar", "Romania", "Russia", "Rwanda", "Réunion", "Saint Barthélemy", "Saint Helena", "Saint Kitts and Nevis", "Saint Lucia", "Saint Martin", "Saint Pierre and Miquelon", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Saudi Arabia", "Senegal", "Serbia", "Serbia and Montenegro", "Seychelles", "Sierra Leone", "Singapore", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "South Korea", "Spain", "Sri Lanka", "Sudan", "Suriname", "Svalbard and Jan Mayen", "Swaziland", "Sweden", "Switzerland", "Syria", "São Tomé and Príncipe", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "U.S. Minor Outlying Islands", "U.S. Miscellaneous Pacific Islands", "U.S. Virgin Islands", "Uganda", "Ukraine", "Union of Soviet Socialist Republics", "United Arab Emirates", "United Kingdom", "United States", "Unknown or Invalid Region", "Uruguay", "Uzbekistan", "Vanuatu", "Vatican City", "Venezuela", "Vietnam", "Wake Island", "Wallis and Futuna", "Western Sahara", "Yemen", "Zambia", "Zimbabwe", "Åland Islands" ] });

    var $fbForm = $("#feedback-form");
    $fbForm.submit(function () {
        if ($(this).parsley().validate() === true) {
            
            $fbForm.parent().fadeOut().next().fadeIn();

            var data = {};
            $fbForm.serializeArray().forEach(function (i) {
                data[i.name] = i.value;
            });

            yaCounter21053995.reachGoal('info_finish');
            $.ajax({
                type: "POST",
                url: "/sender/feedback.html",
                data: data,
                success: function (data) {
                    console.log(data);
                },
                error: function (xhr, status, error) {
                    console.log('AJAX error');
                    console.log(xhr);
                    console.log(status);
                    console.log(error);
                }
            });
        } else {
            console.log("Feedback fail");
        }
        return false;
    });

    var $regForm = $("#registration-form");
   $regForm.submit(function () {
        if ($(this).parsley().validate() === true) {
            $regForm.parent().fadeOut().next().fadeIn();

            var data = {};
            $regForm.serializeArray().forEach(function (i) {
                data[i.name] = i.value;
            });
console.log(data)
            // Registration form has sended
            yaCounter21053995.reachGoal('reg_finish');

            //Send info to tracker
            $.ajax({
                type: "POST",
                url: "/sender/registration.html",
                data: data,
                success: function (data) {
                    console.log(data);
                },
                error: function (xhr, status, error) {
                    console.log('AJAX error');
                    console.log(xhr);
                    console.log(status);
                    console.log(error);
                }
            });

            // Send to mailchimp
            if ($('#r_subscribe').attr('checked') == 'checked') {
                $.ajax({
                    type: "GET",
                    url: 'https://expay.us3.list-manage.com/subscribe/post-json?u=a40e4b16485477ff1f3acec79&amp;id=6e9f0eca69&c=?',
                    crossDomain: true,
                    dataType: 'jsonp',
                    data: {
                        EMAIL: $('.registration form #r_email').val(),
                        FNAME: $('.registration form #r_firstname').val(),
                        LNAME: $('.registration form #r_lastname').val()
                    },

                    success: function (data) {
                        console.log("Mailchimp done");
                    }
                });
            }
        } else {
            console.log("registration fail");
        }
        return false;
    });


    /* header */
    $(window).scroll(function () {

        var panelH = $('.headerWrap');
        posH = panelH.offset();

        if ($(this).scrollTop() > posH.top + panelH.height() && panelH.hasClass('noFixed')) {
            panelH.removeClass('noFixed').addClass('fixed');
        }
        else if ($(this).scrollTop() <= posH.top && panelH.hasClass('fixed')) {
            panelH.hide('fast');
            panelH.removeClass('fixed').addClass('noFixed');
            panelH.show('fast');
        }

    });


    // parallax
    $(window).scroll(function () {
        var windowTop = $(window).scrollTop();
        $('.parallax').css('background-position', 'center ' + windowTop * 0.3 + 'px');
        /*$('#layer_1').css('top', '-' + windowTop * 0.1 + 'px');*/
    });


    // logo header to top
    $('.logoBox.homePage a').bind('click.smoothscroll', function (e) {
        e.preventDefault();

        var target = this.hash,
            $target = $(target);

        $('html, body').stop().animate({
            'scrollTop': $target.offset().top
        }, 900, 'swing', function () {
            window.location.hash = target;
        });
    });

    // partners
    $('.showMore').click(function () {
        $(this).toggleClass('open');
        $(this).prev().slideToggle();
        return false;
    });

    // popup contacts open
    $('.link-feedback').click(function () {
        $('.feedback, .layerBox').fadeIn();
        yaCounter21053995.reachGoal('info_open');
        return false;
    });

    // popup registration open
    $('.btn-tab-form').click(function () {
        $('.registration, .layerBox').fadeIn();
        // Registration form is open
        yaCounter21053995.reachGoal('reg_open');
        return false;
    });

    // popup close
    $('.popupClose, .layerBox').click(function () {
        $('.popupBox, .layerBox').fadeOut();
        return false;
    });

    /* table (color tr) */
    $('.content table tbody tr:even').addClass('color');

});
/* / on load */